package com.example.searchandapi.data

import com.google.gson.annotations.SerializedName



data class forcastModels(
    @SerializedName("main")
    val mainweather: WeatherModel,
    @SerializedName("sys")
    val syscountry: Country,
    @SerializedName("name")
    val namestr: String
)

data class WeatherModel(
    @SerializedName("humidity")
    val humidity: Int,
    @SerializedName("temp")
    val temp: Float,
)

data class Country(
    @SerializedName("country")
    val countrystr: String
)

