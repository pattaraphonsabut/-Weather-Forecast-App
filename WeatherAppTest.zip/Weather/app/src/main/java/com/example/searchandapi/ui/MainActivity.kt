package com.example.searchandapi.ui


import android.os.Bundle
import android.util.Log
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import com.example.searchandapi.R
import com.example.searchandapi.data.forcastModels
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class MainActivity : AppCompatActivity() {

    private var forecastObject: forcastModels? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        callForcastAPI(city = "Bangkok",appID = "009918ccf0bb21333c611a553084e48f")
        setupSearch()
    }


        private fun callForcastAPI(city : String, appID : String) {
        val forcastAPI =
            Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ForcastAPI::class.java)
                .showSelectedWeather(city = city, appid = appID)
        forcastAPI.enqueue(object : Callback<forcastModels> {
            override fun onFailure(call: Call<forcastModels>, t: Throwable) {
                // Print Error Message
              print(t.localizedMessage)
            }
            override fun onResponse(call: Call<forcastModels>, response: Response<forcastModels>) {
                forecastObject = response.body()!!
                setupUI(temp = String.format("%.0f",   response.body()!!.mainweather.temp - 273))
            }
        })
    }


    private fun setupUI(temp : String) {
        cityname.text = "${forecastObject!!.namestr}, ${forecastObject!!.syscountry.countrystr}"
        tempui.text = "$temp°C"
        humidityui.text = "${forecastObject!!.mainweather.humidity}% "

        changeToF.setOnClickListener {
            val tempF =
                String.format("%.0f", ((forecastObject!!.mainweather.temp - 273) * 9 / 5) + 32)
            tempui.text = "${tempF}°F"
        }
        changeToC.setOnClickListener {
            tempui.text = "${temp}°C"
        }
    }

    private fun setupSearch() {
        searchCity.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(s: String): Boolean {
                return true
            }
            override fun onQueryTextSubmit(s: String): Boolean {
                callForcastAPI(city = s,appID = "009918ccf0bb21333c611a553084e48f")
                return true
            }
        })
    }



}


