package com.example.searchandapi.ui

import com.example.searchandapi.data.forcastModels
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface ForcastAPI {

    @GET("data/2.5/forecast")
    fun showSelectedForcast(
        @Query("q") city2: String,
        @Query("appid") appid2: String,
    ): Call<forcastModels>

    @GET("data/2.5/weather")
    fun showSelectedWeather(
        @Query("q") city: String,
        @Query("appid") appid: String,
    ): Call<forcastModels>
}

